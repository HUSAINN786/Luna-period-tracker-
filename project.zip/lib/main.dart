import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:timezone/timezone.dart' as tz;

const rose = Color(0xFFFF5C8A), teal = Color(0xFF5AD1C4), lav = Color(0xFFB28DFF), amb = Color(0xFFFFB454);
const bg = Color(0xFF0E0A12), cardC = Color(0xFF1A1320);
const phCol = {'Menstrual': rose, 'Follicular': lav, 'Fertile': teal, 'Luteal': amb, 'Late': Color(0xFFFF8A65)};
const moods = ['😊 Happy', '😐 Okay', '😔 Sad', '😠 Irritable', '😰 Anxious'];
const syms = ['Cramps', 'Headache', 'Bloating', 'Acne', 'Fatigue', 'Cravings', 'Backache', 'Nausea'];
const flows = ['None', 'Light', 'Medium', 'Heavy'];
const mon = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const wd = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
const bounce = BouncingScrollPhysics();
const pad = EdgeInsets.fromLTRB(20, 12, 20, 40);
const defs = {
  'period': ['Period coming', 'Your period is expected in {n} day(s).'],
  'fertile': ['Fertile window', 'Your fertile window starts today.'],
  'ovulation': ['Ovulation day', 'Ovulation is estimated today.'],
  'late': ['Period late', 'Your period is 2 days late. Log it when it starts.'],
  'log': ['Daily check-in', 'How are you feeling today? Log your day.'],
  'pill': ['Medicine reminder', 'Time to take your medicine.'],
};
const tips = {
  'Menstrual': 'Iron-rich food, warm drinks and gentle stretching help. Rest more if you feel tired.',
  'Follicular': 'Energy is rising. A great time for workouts, new plans and strength training.',
  'Fertile': 'Energy and mood often peak. Stay hydrated. Fertile days are only an estimate.',
  'Luteal': 'PMS may show up. Cut caffeine, eat magnesium-rich food and prioritise sleep.',
  'Late': 'Stress, travel and sleep can shift cycles. Consider a test if pregnancy is possible.',
};

final np = FlutterLocalNotificationsPlugin();

DateTime add(DateTime d, int n) => DateTime(d.year, d.month, d.day + n);
int dd(DateTime a, DateTime b) => (a.difference(b).inHours / 24).round();
String key(DateTime d) => '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

class Ring extends CustomPainter {
  final double v, sw;
  final Color c;
  Ring(this.v, this.c, this.sw);
  @override
  void paint(Canvas cv, Size s) {
    final r = Rect.fromLTWH(sw, sw, s.width - sw * 2, s.height - sw * 2);
    final p = Paint()..style = PaintingStyle.stroke..strokeWidth = sw..strokeCap = StrokeCap.round;
    cv.drawArc(r, 0, 6.2832, false, p..color = Colors.white10);
    cv.drawArc(r, -1.5708, 6.2832 * v, false, p..color = c);
  }
  @override
  bool shouldRepaint(Ring o) => o.v != v || o.c != c;
}

class Logo extends StatelessWidget {
  final double s;
  const Logo(this.s, {super.key});
  @override
  Widget build(BuildContext context) => Container(
      width: s,
      height: s,
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(s * .26),
          gradient: const LinearGradient(colors: [Color(0xFFFF7BA5), Color(0xFFD63A6E)], begin: Alignment.topLeft, end: Alignment.bottomRight),
          boxShadow: [BoxShadow(color: rose.withOpacity(.4), blurRadius: s / 3)]),
      child: Icon(Icons.water_drop_rounded, color: Colors.white, size: s * .55));
}

class Bounce extends StatefulWidget {
  final Widget child;
  final VoidCallback onTap;
  const Bounce({super.key, required this.child, required this.onTap});
  @override
  State<Bounce> createState() => _B();
}

class _B extends State<Bounce> {
  bool d = false;
  @override
  Widget build(BuildContext c) => GestureDetector(
      onTapDown: (_) => setState(() => d = true),
      onTapUp: (_) {
        setState(() => d = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => d = false),
      child: AnimatedScale(scale: d ? .94 : 1, duration: const Duration(milliseconds: 120), child: widget.child));
}

class PinLock extends StatefulWidget {
  final String pin;
  final VoidCallback ok;
  const PinLock(this.pin, this.ok, {super.key});
  @override
  State<PinLock> createState() => _PL();
}

class _PL extends State<PinLock> {
  String e = '';
  bool bad = false;
  void tap(String k) {
    HapticFeedback.selectionClick();
    setState(() {
      bad = false;
      if (k == '<') {
        if (e.isNotEmpty) e = e.substring(0, e.length - 1);
      } else if (e.length < 4) {
        e += k;
      }
    });
    if (e.length == 4) {
      if (e == widget.pin) {
        widget.ok();
      } else {
        Future.delayed(const Duration(milliseconds: 300), () {
          if (mounted) setState(() {
            e = '';
            bad = true;
          });
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          const Logo(70),
          const SizedBox(height: 20),
          Text(bad ? 'Wrong PIN' : 'Enter PIN', style: TextStyle(fontSize: 18, color: bad ? Colors.redAccent : Colors.white70)),
          const SizedBox(height: 18),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: List.generate(4, (i) => AnimatedContainer(duration: const Duration(milliseconds: 200), margin: const EdgeInsets.all(8), width: 16, height: 16, decoration: BoxDecoration(shape: BoxShape.circle, color: i < e.length ? rose : Colors.white12)))),
          const SizedBox(height: 30),
          for (final r in [['1','2','3'],['4','5','6'],['7','8','9'],['','0','<']])
            Row(mainAxisAlignment: MainAxisAlignment.center, children: r.map((k) => Padding(
                padding: const EdgeInsets.all(8),
                child: k.isEmpty ? const SizedBox(width: 72, height: 72) : Bounce(onTap: () => tap(k), child: Container(width: 72, height: 72, alignment: Alignment.center, decoration: const BoxDecoration(shape: BoxShape.circle, color: cardC), child: k == '<' ? const Icon(Icons.backspace_outlined) : Text(k, style: const TextStyle(fontSize: 26)))))).toList()),
        ])),
      );
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await np.initialize(const InitializationSettings(android: AndroidInitializationSettings('@drawable/ic_stat')));
    await np.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()?.requestNotificationsPermission();
  } catch (_) {}
  runApp(const App());
}

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Luna',
        theme: ThemeData.dark(useMaterial3: true).copyWith(
            scaffoldBackgroundColor: bg,
            colorScheme: const ColorScheme.dark(primary: rose),
            navigationBarTheme: NavigationBarThemeData(backgroundColor: cardC, indicatorColor: rose.withOpacity(.25))),
        home: const Splash(),
      );
}

class Splash extends StatefulWidget {
  const Splash({super.key});
  @override
  State<Splash> createState() => _SplashS();
}

class _SplashS extends State<Splash> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 1700), () {
      if (!mounted) return;
      Navigator.of(context).pushReplacement(PageRouteBuilder(
          transitionDuration: const Duration(milliseconds: 600),
          pageBuilder: (_, __, ___) => const Shell(),
          transitionsBuilder: (_, a, __, c) => FadeTransition(opacity: a, child: c)));
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: Center(
          child: TweenAnimationBuilder<double>(
            tween: Tween(begin: 0, end: 1),
            duration: const Duration(milliseconds: 1200),
            curve: Curves.elasticOut,
            builder: (_, v, __) => Opacity(
              opacity: v.clamp(0.0, 1.0),
              child: Transform.scale(scale: v, child: const Column(mainAxisSize: MainAxisSize.min, children: [
                Logo(100),
                SizedBox(height: 18),
                Text('Luna', style: TextStyle(fontSize: 32, fontWeight: FontWeight.w700, letterSpacing: 3)),
              ])),
            ),
          ),
        ),
      );
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _S();
}

class _S extends State<Shell> with SingleTickerProviderStateMixin {
  int tab = 0, cl = 28, pl = 5;
  bool loaded = false, locked = false;
  String pin = '';
  List<String> starts = [];
  Map logs = {}, cfg = {};
  late DateTime month = DateTime(DateTime.now().year, DateTime.now().month);
  late final AnimationController pc = AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat(reverse: true);

  DateTime get now => DateTime.now();
  DateTime get today => DateTime(now.year, now.month, now.day);
  List<DateTime> get st => starts.map((e) => DateTime.parse(e)).toList();
  DateTime? get lastStart => starts.isEmpty ? null : DateTime.parse(starts.last);
  List<int> get gaps {
    final s = st;
    return [for (var i = 1; i < s.length; i++) dd(s[i], s[i - 1])];
  }
  int get clen {
    final g = gaps;
    if (g.isEmpty) return cl;
    final l = g.length > 6 ? g.sublist(g.length - 6) : g;
    return (l.reduce((a, b) => a + b) / l.length).round().clamp(20, 45).toInt();
  }

  @override
  void initState() {
    super.initState();
    load();
  }

  @override
  void dispose() {
    pc.dispose();
    super.dispose();
  }

  void fromMap(Map m) {
    starts = List<String>.from(m['s'] ?? []);
    starts.sort();
    logs = Map.from(m['l'] ?? {});
    cfg = Map.from(m['c'] ?? {});
    cl = (m['cl'] ?? 28) as int;
    pl = (m['pl'] ?? 5) as int;
    pin = (m['pin'] ?? '') as String;
  }

  Map toMap() => {'s': starts, 'l': logs, 'c': cfg, 'cl': cl, 'pl': pl, 'pin': pin};

  Future load() async {
    final p = await SharedPreferences.getInstance();
    final s = p.getString('luna');
    if (s != null) fromMap(jsonDecode(s));
    locked = pin.isNotEmpty;
    setState(() => loaded = true);
    resched();
  }

  Future save() async {
    setState(() {});
    final p = await SharedPreferences.getInstance();
    await p.setString('luna', jsonEncode(toMap()));
  }

  void snack(String m) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<String?> ask(String t, {bool number = true, String init = ''}) {
    final c = TextEditingController(text: init);
    return showDialog<String>(
        context: context,
        builder: (d) => AlertDialog(
            title: Text(t),
            content: TextField(controller: c, autofocus: true, maxLines: number ? 1 : 4, minLines: 1, keyboardType: number ? TextInputType.number : TextInputType.text),
            actions: [
              TextButton(onPressed: () => Navigator.pop(d), child: const Text('Cancel')),
              TextButton(onPressed: () => Navigator.pop(d, c.text), child: const Text('OK')),
            ]));
  }

  // ---------- notifications ----------
  Map cfgOf(String k) {
    final h = {'period': 9, 'fertile': 9, 'ovulation': 9, 'late': 10, 'log': 21, 'pill': 8}[k]!;
    final base = {'on': k != 'ovulation' && k != 'pill', 'h': h, 'm': 0, 'n': 2, 'msg': defs[k]![1]};
    return {...base, ...(cfg[k] ?? {})};
  }

  void setCfg(String k, String f, dynamic v) {
    cfg[k] = {...cfgOf(k), f: v};
    save();
    resched();
  }

  NotificationDetails get nd => NotificationDetails(
      android: AndroidNotificationDetails('luna_reminders', 'Reminders', channelDescription: 'Cycle reminders', importance: Importance.high, priority: Priority.high, icon: '@drawable/ic_stat'));

  Future sched(int id, String t, String b, DateTime when, {bool daily = false}) => np.zonedSchedule(id, t, b, tz.TZDateTime.from(when, tz.local), nd,
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
      uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
      matchDateTimeComponents: daily ? DateTimeComponents.time : null);

  Future resched() async {
    try {
      await np.cancelAll();
      final n = now;
      var base = 1;
      for (final k in defs.keys) {
        base += 10;
        final c = cfgOf(k);
        if (c['on'] != true) continue;
        final h = c['h'] as int, mi = c['m'] as int;
        final title = defs[k]![0];
        final body = (c['msg'] as String).replaceAll('{n}', '${c['n']}');
        if (k == 'log' || k == 'pill') {
          var t = DateTime(n.year, n.month, n.day, h, mi);
          if (!t.isAfter(n)) t = t.add(const Duration(days: 1));
          await sched(base, title, body, t, daily: true);
        } else {
          final l = lastStart;
          if (l == null) continue;
          for (var j = 1; j <= 4; j++) {
            final s = add(l, clen * j);
            final d = k == 'period' ? add(s, -(c['n'] as int)) : k == 'fertile' ? add(s, -19) : k == 'ovulation' ? add(s, -14) : add(s, 2);
            final at = DateTime(d.year, d.month, d.day, h, mi);
            if (at.isAfter(n)) await sched(base + j, title, body, at);
          }
        }
      }
    } catch (_) {}
  }

  // ---------- cycle maths ----------
  String phase(DateTime x) {
    final l = lastStart!;
    final d = dd(x, l) + 1;
    if (d > clen) return 'Late';
    if (d <= pl) return 'Menstrual';
    final k = dd(x, add(l, clen - 14));
    if (k >= -5 && k <= 1) return 'Fertile';
    return k < -5 ? 'Follicular' : 'Luteal';
  }

  bool isPeriod(DateTime x) => st.any((s) {
        final k = dd(x, s);
        return k >= 0 && k < pl;
      });
  bool isPred(DateTime x) {
    final l = lastStart;
    if (l == null) return false;
    for (var j = 1; j <= 4; j++) {
      final k = dd(x, add(l, clen * j));
      if (k >= 0 && k < pl) return true;
    }
    return false;
  }
  int fert(DateTime x) {
    final l = lastStart;
    if (l == null) return 0;
    for (var j = 1; j <= 4; j++) {
      final o = dd(x, add(l, clen * j - 14));
      if (o == 0) return 2;
      if (o >= -5 && o <= 1) return 1;
    }
    return 0;
  }

  // ---------- widgets ----------
  Widget anim(int i, Widget child) => TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 400 + i * 80),
      curve: Curves.easeOut,
      builder: (_, v, ch) => Opacity(opacity: v, child: Transform.translate(offset: Offset(0, 24 * (1 - v)), child: ch)),
      child: child);

  Widget box(Widget c, {Color? col}) => Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(color: col ?? cardC, borderRadius: BorderRadius.circular(24), border: Border.all(color: Colors.white10)),
      child: c);

  Widget title(String t) => Padding(padding: const EdgeInsets.only(top: 8, bottom: 16), child: Text(t, style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w800)));
  Widget sec(String t) => Padding(padding: const EdgeInsets.only(top: 6, bottom: 10), child: Text(t, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)));
  Widget label(String t) => Padding(padding: const EdgeInsets.only(top: 14, bottom: 6), child: Text(t, style: const TextStyle(color: Colors.white60)));
  Widget stat(String l, String v) => Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text(l, style: const TextStyle(color: Colors.white60)),
        Flexible(child: Text(v, textAlign: TextAlign.right, style: const TextStyle(fontWeight: FontWeight.bold))),
      ]));

  Widget ring(double v, Color c, double size, Widget child) => TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: v.clamp(0.0, 1.0).toDouble()),
      duration: const Duration(milliseconds: 1100),
      curve: Curves.easeOutCubic,
      builder: (_, x, __) => SizedBox(width: size, height: size, child: CustomPaint(painter: Ring(x, c, 14), child: Center(child: child))));

  void celebrate(String e) {
    showDialog(
        context: context,
        builder: (d) => Center(child: TweenAnimationBuilder<double>(tween: Tween(begin: 0, end: 1), duration: const Duration(milliseconds: 800), curve: Curves.elasticOut, builder: (_, v, __) => Transform.scale(scale: v, child: Text(e, style: const TextStyle(fontSize: 90, decoration: TextDecoration.none))))));
    Future.delayed(const Duration(milliseconds: 1300), () {
      if (mounted) Navigator.of(context).pop();
    });
  }

  void startToday() {
    final k = key(today);
    if (!starts.contains(k)) {
      starts.add(k);
      starts.sort();
    }
    HapticFeedback.mediumImpact();
    save();
    resched();
    celebrate('🩷');
  }

  void setMood(String m) {
    final k = key(today);
    final e = Map.from(logs[k] ?? {'f': 0, 'y': [], 'n': ''});
    e['m'] = m;
    logs[k] = e;
    HapticFeedback.selectionClick();
    save();
  }

  Widget home() {
    final l = lastStart, n = today;
    final k = key(n);
    final curMood = ((logs[k] ?? {})['m'] ?? '') as String;
    final hdr = Row(children: [
      const Logo(42),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Luna', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
        Text('${wd[n.weekday % 7]}, ${n.day} ${mon[n.month - 1]}', style: const TextStyle(color: Colors.white60)),
      ])),
    ]);
    if (l == null) {
      return ListView(physics: bounce, padding: pad, children: [
        hdr,
        const SizedBox(height: 30),
        anim(0, box(Column(children: [
          const Text('🌸', style: TextStyle(fontSize: 64)),
          const SizedBox(height: 12),
          const Text('Welcome to Luna', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          const Text('Log the first day of your last period and Luna will predict your next period, fertile window and ovulation.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white60)),
          const SizedBox(height: 20),
          Bounce(onTap: () => logSheet(n), child: Container(width: double.infinity, padding: const EdgeInsets.all(16), alignment: Alignment.center, decoration: BoxDecoration(color: rose, borderRadius: BorderRadius.circular(18)), child: const Text('Log my last period', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)))),
        ]))),
      ]);
    }
    final cd = dd(n, l) + 1, ph = phase(n), col = phCol[ph]!;
    final nx = add(l, clen), dn = dd(nx, n);
    var o = add(l, clen - 14);
    while (dd(o, n) < -1) {
      o = add(o, clen);
    }
    final fs = add(o, -5), fe = add(o, 1);
    final done = starts.contains(k);
    return ListView(physics: bounce, padding: pad, children: [
      hdr,
      const SizedBox(height: 16),
      anim(0, box(Column(children: [
        AnimatedBuilder(animation: pc, builder: (_, ch) => Transform.scale(scale: 1 + pc.value * .03, child: ch), child: ring(cd / clen, col, 230, Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('Cycle day', style: TextStyle(color: Colors.white60)),
          Text('$cd', style: const TextStyle(fontSize: 60, fontWeight: FontWeight.w800)),
          Text(ph, style: TextStyle(color: col, fontWeight: FontWeight.w700, fontSize: 16)),
        ]))),
        const SizedBox(height: 18),
        Text(dn < 0 ? 'Period late by ${-dn} day${-dn == 1 ? '' : 's'}' : dn == 0 ? 'Period expected today' : 'Next period in $dn day${dn == 1 ? '' : 's'}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
        Text('${wd[nx.weekday % 7]}, ${nx.day} ${mon[nx.month - 1]}', style: const TextStyle(color: Colors.white60)),
      ]))),
      anim(1, Row(children: [
        Expanded(child: box(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Fertile window', style: TextStyle(color: Colors.white60)), const SizedBox(height: 4), Text('${fs.day} ${mon[fs.month - 1]} – ${fe.day} ${mon[fe.month - 1]}', style: const TextStyle(fontWeight: FontWeight.w700, color: teal))]))),
        const SizedBox(width: 12),
        Expanded(child: box(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Ovulation', style: TextStyle(color: Colors.white60)), const SizedBox(height: 4), Text('${o.day} ${mon[o.month - 1]}', style: const TextStyle(fontWeight: FontWeight.w700, color: teal))]))),
      ])),
      anim(2, Bounce(onTap: done ? () {} : startToday, child: Container(margin: const EdgeInsets.only(bottom: 14), width: double.infinity, padding: const EdgeInsets.all(16), alignment: Alignment.center, decoration: BoxDecoration(color: done ? Colors.white12 : rose, borderRadius: BorderRadius.circular(18)), child: Text(done ? 'Period logged today ✓' : 'Period started today', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16))))),
      anim(3, box(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('How do you feel?', style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 12),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: moods.map((m) => GestureDetector(
            onTap: () => setMood(m),
            child: AnimatedScale(scale: curMood == m ? 1.25 : 1, duration: const Duration(milliseconds: 250), curve: Curves.easeOutBack, child: Container(padding: const EdgeInsets.all(8), decoration: BoxDecoration(shape: BoxShape.circle, color: curMood == m ? rose.withOpacity(.25) : Colors.transparent), child: Text(m.split(' ')[0], style: const TextStyle(fontSize: 30)))))).toList()),
      ]))),
      anim(4, box(col: col.withOpacity(.12), Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('$ph phase tip', style: TextStyle(color: col, fontWeight: FontWeight.w700)),
        const SizedBox(height: 6),
        Text(tips[ph]!),
      ]))),
    ]);
  }

  void logSheet(DateTime day) {
    final k = key(day);
    final Map ex = logs[k] ?? {};
    int flow = (ex['f'] ?? 0) as int;
    String mood = (ex['m'] ?? '') as String;
    final sy = List<String>.from(ex['y'] ?? []);
    final note = TextEditingController(text: (ex['n'] ?? '') as String);
    bool start = starts.contains(k);
    showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        backgroundColor: cardC,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
        builder: (c) => StatefulBuilder(
            builder: (c, ss) => Padding(
                padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(c).viewInsets.bottom + 20),
                child: SingleChildScrollView(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                  Text('${wd[day.weekday % 7]}, ${day.day} ${mon[day.month - 1]}', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                  SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('Period started this day'), value: start, onChanged: (v) => ss(() => start = v)),
                  label('Flow'),
                  Wrap(spacing: 8, children: List.generate(4, (i) => ChoiceChip(label: Text(flows[i]), selected: flow == i, onSelected: (_) => ss(() => flow = i)))),
                  label('Mood'),
                  Wrap(spacing: 8, children: moods.map((m) => ChoiceChip(label: Text(m), selected: mood == m, onSelected: (_) => ss(() => mood = mood == m ? '' : m))).toList()),
                  label('Symptoms'),
                  Wrap(spacing: 8, children: syms.map((x) => FilterChip(label: Text(x), selected: sy.contains(x), onSelected: (v) => ss(() => v ? sy.add(x) : sy.remove(x)))).toList()),
                  const SizedBox(height: 10),
                  TextField(controller: note, decoration: const InputDecoration(labelText: 'Note (optional)')),
                  const SizedBox(height: 16),
                  FilledButton(
                      style: FilledButton.styleFrom(backgroundColor: rose, foregroundColor: Colors.white, minimumSize: const Size.fromHeight(52)),
                      onPressed: () {
                        if (flow == 0 && mood.isEmpty && sy.isEmpty && note.text.isEmpty) {
                          logs.remove(k);
                        } else {
                          logs[k] = {'f': flow, 'm': mood, 'y': sy, 'n': note.text};
                        }
                        if (start && !starts.contains(k)) {
                          starts.add(k);
                          starts.sort();
                        }
                        if (!start) starts.remove(k);
                        Navigator.pop(c);
                        HapticFeedback.mediumImpact();
                        save();
                        resched();
                      },
                      child: const Text('Save')),
                ])))));
  }

  Widget cell(DateTime x) {
    final per = isPeriod(x), pred = !per && isPred(x), f = fert(x), isT = dd(x, today) == 0, has = logs.containsKey(key(x));
    Color? fill;
    if (per) fill = rose;
    else if (f == 2) fill = teal;
    else if (f == 1) fill = teal.withOpacity(.22);
    return GestureDetector(
        onTap: () => logSheet(x),
        child: Container(
            margin: const EdgeInsets.all(3),
            decoration: BoxDecoration(shape: BoxShape.circle, color: fill, border: Border.all(color: isT ? Colors.white : pred ? rose : Colors.transparent, width: isT ? 2 : 1.5)),
            child: Stack(alignment: Alignment.center, children: [
              Text('${x.day}', style: TextStyle(fontWeight: per || f == 2 ? FontWeight.w800 : FontWeight.w500, color: f == 2 ? Colors.black : Colors.white)),
              if (has) Positioned(bottom: 4, child: Container(width: 4, height: 4, decoration: const BoxDecoration(shape: BoxShape.circle, color: amb))),
            ])));
  }

  Widget cal() {
    final first = DateTime(month.year, month.month, 1);
    final lead = first.weekday % 7;
    final days = DateTime(month.year, month.month + 1, 0).day;
    final cells = <Widget>[for (var i = 0; i < lead; i++) const SizedBox(), for (var d = 1; d <= days; d++) cell(DateTime(month.year, month.month, d))];
    Widget dot(Color c, String t, {bool ring = false}) => Row(mainAxisSize: MainAxisSize.min, children: [Container(width: 12, height: 12, decoration: BoxDecoration(shape: BoxShape.circle, color: ring ? null : c, border: ring ? Border.all(color: c, width: 1.5) : null)), const SizedBox(width: 6), Text(t, style: const TextStyle(fontSize: 12, color: Colors.white60))]);
    return ListView(physics: bounce, padding: pad, children: [
      title('Calendar'),
      box(Column(children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          IconButton(onPressed: () => setState(() => month = DateTime(month.year, month.month - 1)), icon: const Icon(Icons.chevron_left_rounded)),
          Text('${mon[month.month - 1]} ${month.year}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
          IconButton(onPressed: () => setState(() => month = DateTime(month.year, month.month + 1)), icon: const Icon(Icons.chevron_right_rounded)),
        ]),
        Row(children: wd.map((w) => Expanded(child: Center(child: Text(w.substring(0, 1), style: const TextStyle(color: Colors.white38))))).toList()),
        const SizedBox(height: 6),
        AnimatedSwitcher(duration: const Duration(milliseconds: 300), child: GridView.count(key: ValueKey(month), crossAxisCount: 7, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), children: cells)),
      ])),
      Wrap(spacing: 14, runSpacing: 8, children: [dot(rose, 'Period'), dot(rose, 'Predicted', ring: true), dot(teal, 'Fertile'), dot(teal, 'Ovulation'), dot(amb, 'Logged')]),
      const SizedBox(height: 10),
      const Text('Tap any day to log flow, mood and symptoms.', style: TextStyle(color: Colors.white38)),
    ]);
  }

  Widget insights() {
    final g = gaps, l6 = g.length > 6 ? g.sublist(g.length - 6) : g;
    final mx = l6.fold(1, (a, b) => b > a ? b : a);
    final reg = g.length < 2 ? '—' : ((g.reduce((a, b) => a > b ? a : b) - g.reduce((a, b) => a < b ? a : b)) <= 7 ? 'Regular' : 'Irregular');
    final sd = <String, List<int>>{};
    final mc = <String, int>{};
    logs.forEach((k, v) {
      final d = DateTime.parse(k);
      DateTime? s;
      for (final x in st) {
        if (!x.isAfter(d)) s = x;
      }
      for (final y in (v['y'] as List)) {
        if (s != null) (sd[y] ??= []).add(dd(d, s) + 1);
      }
      final m = v['m'] as String;
      if (m.isNotEmpty) mc[m] = (mc[m] ?? 0) + 1;
    });
    final top = sd.entries.toList()..sort((a, b) => b.value.length.compareTo(a.value.length));
    final mm = mc.values.fold(1, (a, b) => b > a ? b : a);
    return ListView(physics: bounce, padding: pad, children: [
      title('Insights'),
      anim(0, box(Column(children: [
        stat('Average cycle', '$clen days'),
        stat('Period length', '$pl days'),
        stat('Regularity', reg),
        stat('Cycles logged', '${g.length}'),
        stat('Last period', lastStart == null ? '—' : '${lastStart!.day} ${mon[lastStart!.month - 1]}'),
      ]))),
      sec('Cycle length'),
      anim(1, box(l6.isEmpty ? const Text('Log two or more periods to see this chart.', style: TextStyle(color: Colors.white60)) : SizedBox(height: 150, child: Row(crossAxisAlignment: CrossAxisAlignment.end, mainAxisAlignment: MainAxisAlignment.spaceAround, children: l6.map((x) => Column(mainAxisAlignment: MainAxisAlignment.end, children: [
        Text('$x', style: const TextStyle(fontSize: 12)),
        const SizedBox(height: 4),
        TweenAnimationBuilder<double>(tween: Tween(begin: 0, end: 100 * x / mx), duration: const Duration(milliseconds: 900), curve: Curves.easeOutCubic, builder: (_, v, __) => Container(width: 26, height: v, decoration: BoxDecoration(color: rose, borderRadius: BorderRadius.circular(8)))),
      ])).toList())))),
      sec('Symptom patterns'),
      anim(2, box(Column(children: top.isEmpty ? [const Text('Log symptoms to see patterns.', style: TextStyle(color: Colors.white60))] : top.take(4).map((e) => stat(e.key, 'usually day ${(e.value.reduce((a, b) => a + b) / e.value.length).round()} · ${e.value.length}x')).toList()))),
      sec('Moods'),
      anim(3, box(Column(children: mc.isEmpty ? [const Text('Log your mood to see this.', style: TextStyle(color: Colors.white60))] : mc.entries.map((e) => Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('${e.key}  ·  ${e.value}'),
        const SizedBox(height: 6),
        TweenAnimationBuilder<double>(tween: Tween(begin: 0, end: e.value / mm), duration: const Duration(milliseconds: 900), curve: Curves.easeOutCubic, builder: (_, v, __) => LinearProgressIndicator(value: v, minHeight: 8, color: lav, backgroundColor: Colors.white10, borderRadius: BorderRadius.circular(8))),
      ]))).toList()))),
    ]);
  }

  Widget notifCard(String k) {
    final c = cfgOf(k);
    final on = c['on'] == true;
    return box(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text(defs[k]![0], style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
        Switch(value: on, activeColor: rose, onChanged: (v) => setCfg(k, 'on', v)),
      ]),
      if (on) ...[
        Row(children: [
          TextButton.icon(
              icon: const Icon(Icons.schedule_rounded, size: 18),
              label: Text(TimeOfDay(hour: c['h'] as int, minute: c['m'] as int).format(context)),
              onPressed: () async {
                final t = await showTimePicker(context: context, initialTime: TimeOfDay(hour: c['h'] as int, minute: c['m'] as int));
                if (t != null) {
                  cfg[k] = {...cfgOf(k), 'h': t.hour, 'm': t.minute};
                  save();
                  resched();
                }
              }),
          if (k == 'period') ...[1, 2, 3].map((i) => Padding(padding: const EdgeInsets.only(left: 6), child: ChoiceChip(label: Text('${i}d before'), selected: c['n'] == i, onSelected: (_) => setCfg(k, 'n', i)))),
        ]),
        Text(c['msg'] as String, style: const TextStyle(color: Colors.white60)),
        TextButton(
            onPressed: () async {
              final r = await ask('Custom message', number: false, init: c['msg'] as String);
              if (r != null && r.trim().isNotEmpty) setCfg(k, 'msg', r.trim());
            },
            child: const Text('Edit message')),
      ],
    ]));
  }

  Widget alerts() => ListView(physics: bounce, padding: pad, children: [
        title('Alerts'),
        ...defs.keys.toList().asMap().entries.map((e) => anim(e.key, notifCard(e.value))),
        OutlinedButton.icon(
            icon: const Icon(Icons.notifications_active_rounded),
            label: const Text('Send test notification'),
            onPressed: () async {
              try {
                await np.show(0, 'Luna', 'Notifications are working ✓', nd);
              } catch (_) {
                snack('Could not send. Allow notifications for Luna in phone settings.');
              }
            }),
        const SizedBox(height: 10),
        const Text('Reminders may arrive a few minutes late because Android saves battery. If they never arrive, allow notifications and turn off battery optimisation for Luna.', style: TextStyle(color: Colors.white38)),
      ]);

  Widget more() => ListView(physics: bounce, padding: pad, children: [
        title('More'),
        box(Column(children: [
          ListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Typical cycle length'),
              subtitle: Text('$cl days (used until 2 cycles are logged)'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () async {
                final v = int.tryParse(await ask('Cycle length (20-45)') ?? '');
                if (v != null && v >= 20 && v <= 45) {
                  cl = v;
                  save();
                  resched();
                }
              }),
          ListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Period length'),
              subtitle: Text('$pl days'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () async {
                final v = int.tryParse(await ask('Period length (2-10)') ?? '');
                if (v != null && v >= 2 && v <= 10) {
                  pl = v;
                  save();
                }
              }),
          ListTile(
              contentPadding: EdgeInsets.zero,
              leading: Icon(pin.isEmpty ? Icons.lock_open_rounded : Icons.lock_rounded, color: rose),
              title: Text(pin.isEmpty ? 'Set app lock (PIN)' : 'Remove app lock'),
              onTap: () async {
                if (pin.isNotEmpty) {
                  pin = '';
                  save();
                  snack('App lock removed');
                  return;
                }
                final v = await ask('Choose a 4-digit PIN');
                if (v != null && v.length == 4 && int.tryParse(v) != null) {
                  pin = v;
                  save();
                  snack('App lock on');
                }
              }),
        ])),
        sec('Backup'),
        box(Column(children: [
          ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.copy_rounded, color: rose),
              title: const Text('Copy backup'),
              subtitle: const Text('Paste it somewhere safe (Notes, WhatsApp)'),
              onTap: () {
                Clipboard.setData(ClipboardData(text: jsonEncode(toMap())));
                snack('Backup copied');
              }),
          ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.restore_rounded, color: rose),
              title: const Text('Restore backup'),
              onTap: () async {
                final r = await ask('Paste backup here', number: false);
                if (r == null || r.isEmpty) return;
                try {
                  fromMap(jsonDecode(r));
                  await save();
                  resched();
                  snack('Restored');
                } catch (_) {
                  snack('Invalid backup');
                }
              }),
        ])),
        const Text('Your data stays on this phone. Luna gives estimates only. It is not medical advice and not a method of birth control.', style: TextStyle(color: Colors.white38)),
      ]);

  @override
  Widget build(BuildContext context) {
    if (!loaded) return const Scaffold();
    if (locked) return PinLock(pin, () => setState(() => locked = false));
    final pages = [home(), cal(), insights(), alerts(), more()];
    return Scaffold(
      body: SafeArea(child: AnimatedSwitcher(duration: const Duration(milliseconds: 300), child: KeyedSubtree(key: ValueKey(tab), child: pages[tab]))),
      bottomNavigationBar: NavigationBar(selectedIndex: tab, onDestinationSelected: (i) {
        HapticFeedback.selectionClick();
        setState(() => tab = i);
      }, destinations: const [
        NavigationDestination(icon: Icon(Icons.favorite_rounded), label: 'Today'),
        NavigationDestination(icon: Icon(Icons.calendar_month_rounded), label: 'Calendar'),
        NavigationDestination(icon: Icon(Icons.insights_rounded), label: 'Insights'),
        NavigationDestination(icon: Icon(Icons.notifications_rounded), label: 'Alerts'),
        NavigationDestination(icon: Icon(Icons.more_horiz_rounded), label: 'More'),
      ]),
    );
  }
}
