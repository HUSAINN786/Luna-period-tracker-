import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:timezone/data/latest_all.dart' as tzd;
import 'package:timezone/timezone.dart' as tz;

const rose = Color(0xFFE8457C), teal = Color(0xFF2BB5A6), lav = Color(0xFF8E6BE0), amb = Color(0xFFF2A33A);
final darkN = ValueNotifier<bool>(false);
Color get bg => darkN.value ? const Color(0xFF14101A) : const Color(0xFFFFF7F9);
Color get cardC => darkN.value ? const Color(0xFF1F1827) : Colors.white;
Color get sub => darkN.value ? Colors.white60 : const Color(0xFF8A7F93);
Color get line => darkN.value ? Colors.white12 : const Color(0xFFF0E3EA);
const phCol = {'Menstrual': rose, 'Follicular': lav, 'Fertile': teal, 'Luteal': amb, 'Late': Color(0xFFFF7043)};
const moods = ['😊 Happy', '😐 Okay', '😔 Sad', '😠 Irritable', '😰 Anxious'];
const syms = ['Cramps', 'Headache', 'Bloating', 'Acne', 'Fatigue', 'Cravings', 'Backache', 'Nausea'];
const flows = ['None', 'Light', 'Medium', 'Heavy'];
const mon = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const wd = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
const bounce = BouncingScrollPhysics();
const pad = EdgeInsets.fromLTRB(20, 12, 20, 40);
const defs = {
  'period': ['Period coming', 'Your period is expected in {n} day(s).'],
  'fertile': ['Fertile window', 'Your fertile window starts today.'],
  'ovulation': ['Ovulation day', 'Ovulation is estimated today.'],
  'late': ['Period late', 'Your period is 2 days late. Log it when it starts.'],
  'stock': ['Stock up', 'Your period is near. Check your pads or tampons.'],
  'log': ['Daily check-in', 'How are you feeling today? Log your day.'],
  'pill': ['Medicine reminder', 'Time to take your medicine.'],
  'water': ['Drink water', 'Time for a glass of water 💧'],
};
const tips = {
  'Menstrual': 'Iron-rich food, warm drinks and gentle stretching help. Rest more if you feel tired.',
  'Follicular': 'Energy is rising. A great time for workouts, new plans and strength training.',
  'Fertile': 'Energy and mood often peak. Stay hydrated. Fertile days are only an estimate.',
  'Luteal': 'PMS may show up. Cut caffeine, eat magnesium-rich food and prioritise sleep.',
  'Late': 'Stress, travel and sleep can shift cycles. Consider a test if pregnancy is possible.',
};

final np = FlutterLocalNotificationsPlugin();

DateTime add(DateTime d, int n) => DateTime(d.year, d.month, d.day + n);
int dd(DateTime a, DateTime b) => (a.difference(b).inHours / 24).round();
String key(DateTime d) => '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
Widget sm(String t, {double s = 14}) => Text(t, style: TextStyle(color: sub, fontSize: s));
Widget bold(String t, {double s = 16}) => Text(t, style: TextStyle(fontSize: s, fontWeight: FontWeight.w700));

class Ring extends CustomPainter {
  final double v, sw;
  final Color c;
  Ring(this.v, this.c, this.sw);
  @override
  void paint(Canvas cv, Size s) {
    final r = Rect.fromLTWH(sw, sw, s.width - sw * 2, s.height - sw * 2);
    final p = Paint()..style = PaintingStyle.stroke..strokeWidth = sw..strokeCap = StrokeCap.round;
    cv.drawArc(r, 0, 6.2832, false, p..color = line);
    cv.drawArc(r, -1.5708, 6.2832 * v, false, p..color = c);
  }
  @override
  bool shouldRepaint(Ring o) => o.v != v || o.c != c;
}

class LineP extends CustomPainter {
  final List<double> v;
  final Color c;
  LineP(this.v, this.c);
  @override
  void paint(Canvas cv, Size s) {
    if (v.length < 2) return;
    final mn = v.reduce((a, b) => a < b ? a : b), mx = v.reduce((a, b) => a > b ? a : b);
    final pts = [for (var i = 0; i < v.length; i++) Offset(i / (v.length - 1) * s.width, s.height - 8 - (v[i] - mn) / (mx - mn + 0.0001) * (s.height - 16))];
    final path = Path()..moveTo(pts.first.dx, pts.first.dy);
    for (final p in pts.skip(1)) {
      path.lineTo(p.dx, p.dy);
    }
    cv.drawPath(path, Paint()..style = PaintingStyle.stroke..strokeWidth = 3..strokeCap = StrokeCap.round..color = c);
    for (final p in pts) {
      cv.drawCircle(p, 4, Paint()..color = c);
    }
  }
  @override
  bool shouldRepaint(LineP o) => true;
}

class Logo extends StatelessWidget {
  final double s;
  const Logo(this.s, {super.key});
  @override
  Widget build(BuildContext context) => Container(
      width: s,
      height: s,
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(s * .26),
          gradient: const LinearGradient(colors: [Color(0xFFFF7BA5), Color(0xFFD63A6E)], begin: Alignment.topLeft, end: Alignment.bottomRight),
          boxShadow: [BoxShadow(color: rose.withOpacity(.35), blurRadius: s / 3)]),
      child: Icon(Icons.water_drop_rounded, color: Colors.white, size: s * .55));
}

class Bounce extends StatefulWidget {
  final Widget child;
  final VoidCallback onTap;
  const Bounce({super.key, required this.child, required this.onTap});
  @override
  State<Bounce> createState() => _B();
}

class _B extends State<Bounce> {
  bool d = false;
  @override
  Widget build(BuildContext c) => GestureDetector(
      onTapDown: (_) => setState(() => d = true),
      onTapUp: (_) {
        setState(() => d = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => d = false),
      child: AnimatedScale(scale: d ? .94 : 1, duration: const Duration(milliseconds: 120), child: widget.child));
}

class PinLock extends StatefulWidget {
  final String pin;
  final VoidCallback ok;
  const PinLock(this.pin, this.ok, {super.key});
  @override
  State<PinLock> createState() => _PL();
}

class _PL extends State<PinLock> {
  String e = '';
  bool bad = false;
  void tap(String k) {
    HapticFeedback.selectionClick();
    setState(() {
      bad = false;
      if (k == '<') {
        if (e.isNotEmpty) e = e.substring(0, e.length - 1);
      } else if (e.length < 4) {
        e += k;
      }
    });
    if (e.length == 4) {
      if (e == widget.pin) {
        widget.ok();
      } else {
        Future.delayed(const Duration(milliseconds: 300), () {
          if (mounted) setState(() {
            e = '';
            bad = true;
          });
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          const Logo(70),
          const SizedBox(height: 20),
          Text(bad ? 'Wrong PIN' : 'Enter PIN', style: TextStyle(fontSize: 18, color: bad ? Colors.redAccent : sub)),
          const SizedBox(height: 18),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: List.generate(4, (i) => AnimatedContainer(duration: const Duration(milliseconds: 200), margin: const EdgeInsets.all(8), width: 16, height: 16, decoration: BoxDecoration(shape: BoxShape.circle, color: i < e.length ? rose : line)))),
          const SizedBox(height: 30),
          for (final r in [['1','2','3'],['4','5','6'],['7','8','9'],['','0','<']])
            Row(mainAxisAlignment: MainAxisAlignment.center, children: r.map((k) => Padding(
                padding: const EdgeInsets.all(8),
                child: k.isEmpty ? const SizedBox(width: 72, height: 72) : Bounce(onTap: () => tap(k), child: Container(width: 72, height: 72, alignment: Alignment.center, decoration: BoxDecoration(shape: BoxShape.circle, color: cardC, border: Border.all(color: line)), child: k == '<' ? const Icon(Icons.backspace_outlined) : Text(k, style: const TextStyle(fontSize: 26)))))).toList()),
        ])),
      );
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    tzd.initializeTimeZones();
    await np.initialize(const InitializationSettings(android: AndroidInitializationSettings('@drawable/ic_stat')));
  } catch (_) {}
  runApp(const App());
}

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => ValueListenableBuilder<bool>(
      valueListenable: darkN,
      builder: (_, d, __) => MaterialApp(
            debugShowCheckedModeBanner: false,
            title: 'Luna',
            theme: ThemeData(
                useMaterial3: true,
                brightness: d ? Brightness.dark : Brightness.light,
                colorScheme: ColorScheme.fromSeed(seedColor: rose, brightness: d ? Brightness.dark : Brightness.light, primary: rose),
                scaffoldBackgroundColor: bg,
                navigationBarTheme: NavigationBarThemeData(backgroundColor: cardC, indicatorColor: rose.withOpacity(.15))),
            home: const Splash(),
          ));
}

class Splash extends StatefulWidget {
  const Splash({super.key});
  @override
  State<Splash> createState() => _SplashS();
}

class _SplashS extends State<Splash> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 1700), () {
      if (!mounted) return;
      Navigator.of(context).pushReplacement(PageRouteBuilder(
          transitionDuration: const Duration(milliseconds: 600),
          pageBuilder: (_, __, ___) => const Shell(),
          transitionsBuilder: (_, a, __, c) => FadeTransition(opacity: a, child: c)));
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: Center(
          child: TweenAnimationBuilder<double>(
            tween: Tween(begin: 0, end: 1),
            duration: const Duration(milliseconds: 1200),
            curve: Curves.elasticOut,
            builder: (_, v, __) => Opacity(
              opacity: v.clamp(0.0, 1.0),
              child: Transform.scale(scale: v, child: const Column(mainAxisSize: MainAxisSize.min, children: [
                Logo(100),
                SizedBox(height: 18),
                Text('Luna', style: TextStyle(fontSize: 32, fontWeight: FontWeight.w700, letterSpacing: 3)),
              ])),
            ),
          ),
        ),
      );
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _S();
}

class _S extends State<Shell> with SingleTickerProviderStateMixin {
  int tab = 0, seg = 0, cl = 28, pl = 5, wg = 2500, stock = 0, use = 4, obStep = 0, obCl = 28, obPl = 5;
  bool loaded = false, locked = false, hide = false, done = false;
  String pin = '', schedInfo = '';
  DateTime? obDate;
  final nameC = TextEditingController();
  List<String> starts = [];
  List rems = [];
  Map logs = {}, cfg = {}, prof = {}, wlog = {};
  late DateTime month = DateTime(DateTime.now().year, DateTime.now().month);
  late final AnimationController pc = AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat(reverse: true);

  DateTime get now => DateTime.now();
  DateTime get today => DateTime(now.year, now.month, now.day);
  List<DateTime> get st => starts.map((e) => DateTime.parse(e)).toList();
  DateTime? get lastStart => starts.isEmpty ? null : DateTime.parse(starts.last);
  String get name => (prof['name'] ?? '') as String;
  String pf(String k) => (prof[k] ?? '') as String;
  List<int> get gaps {
    final s = st;
    return [for (var i = 1; i < s.length; i++) dd(s[i], s[i - 1])];
  }
  int get clen {
    final g = gaps;
    if (g.isEmpty) return cl;
    final l = g.length > 6 ? g.sublist(g.length - 6) : g;
    return (l.reduce((a, b) => a + b) / l.length).round().clamp(20, 45).toInt();
  }

  @override
  void initState() {
    super.initState();
    load();
  }

  @override
  void dispose() {
    pc.dispose();
    super.dispose();
  }

  void fromMap(Map m) {
    starts = List<String>.from(m['s'] ?? []);
    starts.sort();
    logs = Map.from(m['l'] ?? {});
    cfg = Map.from(m['c'] ?? {});
    rems = List.from(m['r'] ?? []);
    prof = Map.from(m['pf'] ?? {});
    wlog = Map.from(m['wl'] ?? {});
    cl = (m['cl'] ?? 28) as int;
    pl = (m['pl'] ?? 5) as int;
    wg = (m['wg'] ?? 2500) as int;
    stock = (m['st'] ?? 0) as int;
    use = (m['us'] ?? 4) as int;
    pin = (m['pin'] ?? '') as String;
    hide = (m['hd'] ?? false) as bool;
    done = (m['dn'] ?? false) as bool;
    darkN.value = (m['dk'] ?? false) as bool;
  }

  Map toMap() => {'s': starts, 'l': logs, 'c': cfg, 'r': rems, 'pf': prof, 'wl': wlog, 'cl': cl, 'pl': pl, 'wg': wg, 'st': stock, 'us': use, 'pin': pin, 'hd': hide, 'dn': done, 'dk': darkN.value};

  Future load() async {
    final p = await SharedPreferences.getInstance();
    final s = p.getString('luna');
    if (s != null) fromMap(jsonDecode(s));
    locked = pin.isNotEmpty;
    setState(() => loaded = true);
    perms();
    resched();
  }

  Future save() async {
    setState(() {});
    final p = await SharedPreferences.getInstance();
    await p.setString('luna', jsonEncode(toMap()));
  }

  void snack(String m) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<String?> ask(String t, {bool number = true, String init = ''}) {
    final c = TextEditingController(text: init);
    return showDialog<String>(
        context: context,
        builder: (d) => AlertDialog(
            title: Text(t),
            content: TextField(controller: c, autofocus: true, maxLines: number ? 1 : 4, minLines: 1, keyboardType: number ? const TextInputType.numberWithOptions(decimal: true) : TextInputType.text),
            actions: [
              TextButton(onPressed: () => Navigator.pop(d), child: const Text('Cancel')),
              TextButton(onPressed: () => Navigator.pop(d, c.text), child: const Text('OK')),
            ]));
  }

  Future editProf(String k, String t) async {
    final r = await ask(t, number: false, init: pf(k));
    if (r != null) {
      prof[k] = r.trim();
      save();
    }
  }

  // ---------- notifications ----------
  Future<String> perms() async {
    try {
      final a = np.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      final ok = await a?.requestNotificationsPermission();
      try {
        await a?.requestExactAlarmsPermission();
      } catch (_) {}
      return ok == false ? 'Notifications are blocked. Allow them in phone Settings → Apps → Luna.' : 'ok';
    } catch (e) {
      return 'Permission error: $e';
    }
  }

  Map cfgOf(String k) {
    final h = {'period': 9, 'fertile': 9, 'ovulation': 9, 'late': 10, 'stock': 10, 'log': 21, 'pill': 8, 'water': 9}[k]!;
    final base = {'on': k != 'ovulation' && k != 'pill' && k != 'water', 'h': h, 'm': 0, 'n': k == 'water' ? 2 : 2, 'msg': defs[k]![1]};
    return {...base, ...(cfg[k] ?? {})};
  }

  void setCfg(String k, String f, dynamic v) {
    cfg[k] = {...cfgOf(k), f: v};
    save();
    resched();
  }

  NotificationDetails get nd => NotificationDetails(
      android: AndroidNotificationDetails('luna_reminders', 'Reminders', channelDescription: 'Cycle reminders', importance: Importance.high, priority: Priority.high, icon: '@drawable/ic_stat'));

  Future sched(int id, String t, String b, DateTime when, {DateTimeComponents? match}) async {
    if (hide) {
      t = 'Luna';
      b = 'You have a reminder';
    }
    final z = tz.TZDateTime.from(when, tz.local);
    try {
      await np.zonedSchedule(id, t, b, z, nd, androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle, uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime, matchDateTimeComponents: match);
    } catch (_) {
      await np.zonedSchedule(id, t, b, z, nd, androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle, uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime, matchDateTimeComponents: match);
    }
  }

  DateTime nextAt(int h, int m, [int? wk]) {
    final n = now;
    var d = DateTime(n.year, n.month, n.day, h, m);
    while (!d.isAfter(n) || (wk != null && d.weekday != wk)) {
      d = d.add(const Duration(days: 1));
    }
    return d;
  }

  Future resched() async {
    try {
      await np.cancelAll();
      final n = now;
      var base = 0;
      for (final k in defs.keys) {
        base += 100;
        final c = cfgOf(k);
        if (c['on'] != true) continue;
        final h = c['h'] as int, mi = c['m'] as int;
        final title = defs[k]![0];
        final body = (c['msg'] as String).replaceAll('{n}', '${c['n']}');
        if (k == 'log' || k == 'pill') {
          await sched(base, title, body, nextAt(h, mi), match: DateTimeComponents.time);
        } else if (k == 'water') {
          var i = 0;
          for (var hh = h; hh <= 21; hh += (c['n'] as int)) {
            await sched(base + i, title, body, nextAt(hh, 0), match: DateTimeComponents.time);
            i++;
          }
        } else {
          final l = lastStart;
          if (l == null) continue;
          if (k == 'stock' && stock >= pl * use) continue;
          for (var j = 1; j <= 4; j++) {
            final s = add(l, clen * j);
            final d = k == 'period' ? add(s, -(c['n'] as int)) : k == 'fertile' ? add(s, -19) : k == 'ovulation' ? add(s, -14) : k == 'stock' ? add(s, -4) : add(s, 2);
            final at = DateTime(d.year, d.month, d.day, h, mi);
            if (at.isAfter(n)) await sched(base + j, title, body, at);
          }
        }
      }
      for (var i = 0; i < rems.length; i++) {
        final r = rems[i];
        if (r['on'] != true) continue;
        final days = List<int>.from(r['d'] ?? []);
        final h = r['h'] as int, mi = r['m'] as int;
        if (days.isEmpty) {
          await sched(1000 + i * 10, r['t'] as String, r['b'] as String, nextAt(h, mi), match: DateTimeComponents.time);
        } else {
          for (final w in days) {
            await sched(1000 + i * 10 + w, r['t'] as String, r['b'] as String, nextAt(h, mi, w), match: DateTimeComponents.dayOfWeekAndTime);
          }
        }
      }
      final p = await np.pendingNotificationRequests();
      schedInfo = '${p.length} reminders scheduled';
    } catch (e) {
      schedInfo = 'Scheduling problem: $e';
    }
    if (mounted) setState(() {});
  }

  // ---------- cycle maths ----------
  String phase(DateTime x) {
    final l = lastStart!;
    final d = dd(x, l) + 1;
    if (d > clen) return 'Late';
    if (d <= pl) return 'Menstrual';
    final k = dd(x, add(l, clen - 14));
    if (k >= -5 && k <= 1) return 'Fertile';
    return k < -5 ? 'Follicular' : 'Luteal';
  }

  bool isPeriod(DateTime x) => st.any((s) {
        final k = dd(x, s);
        return k >= 0 && k < pl;
      });
  bool isPred(DateTime x) {
    final l = lastStart;
    if (l == null) return false;
    for (var j = 1; j <= 4; j++) {
      final k = dd(x, add(l, clen * j));
      if (k >= 0 && k < pl) return true;
    }
    return false;
  }
  int fert(DateTime x) {
    final l = lastStart;
    if (l == null) return 0;
    for (var j = 1; j <= 4; j++) {
      final o = dd(x, add(l, clen * j - 14));
      if (o == 0) return 2;
      if (o >= -5 && o <= 1) return 1;
    }
    return 0;
  }
  String chance(DateTime x) {
    final l = lastStart;
    if (l == null || isPeriod(x)) return 'Low';
    for (var j = 1; j <= 4; j++) {
      final o = dd(x, add(l, clen * j - 14));
      if (o == 0 || o == -1) return 'High';
      if (o >= -5 && o <= 1) return 'Medium';
    }
    return 'Low';
  }
  String? warn() {
    final g = gaps, l = lastStart;
    if (g.isNotEmpty && (g.last < 21 || g.last > 35)) return 'Your last cycle was ${g.last} days. Cycles shorter than 21 or longer than 35 days are worth mentioning to a doctor.';
    if (l != null && dd(today, add(l, clen)) > 7) return 'Your period is more than a week late. A pregnancy test or a doctor visit may help.';
    return null;
  }

  // ---------- helpers ----------
  Map dayLog(String k) => Map.from(logs[k] ?? {'f': 0, 'm': '', 'y': [], 'n': '', 'p': 0});

  Widget anim(int i, Widget child) => TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 400 + i * 80),
      curve: Curves.easeOut,
      builder: (_, v, ch) => Opacity(opacity: v, child: Transform.translate(offset: Offset(0, 24 * (1 - v)), child: ch)),
      child: child);

  Widget box(Widget c, {Color? col}) => Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(color: col ?? cardC, borderRadius: BorderRadius.circular(24), border: Border.all(color: line), boxShadow: [BoxShadow(color: rose.withOpacity(.05), blurRadius: 16, offset: const Offset(0, 6))]),
      child: c);

  Widget title(String t) => Padding(padding: const EdgeInsets.only(top: 8, bottom: 16), child: Text(t, style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w800)));
  Widget sec(String t) => Padding(padding: const EdgeInsets.only(top: 6, bottom: 10), child: bold(t, s: 20));
  Widget label(String t) => Padding(padding: const EdgeInsets.only(top: 14, bottom: 6), child: sm(t));
  Widget stat(String l, String v) => Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [sm(l), Flexible(child: Text(v, textAlign: TextAlign.right, style: const TextStyle(fontWeight: FontWeight.bold)))]));
  Widget primary(String t, VoidCallback f, {Color? c}) => Bounce(onTap: f, child: Container(margin: const EdgeInsets.only(bottom: 14), width: double.infinity, padding: const EdgeInsets.all(16), alignment: Alignment.center, decoration: BoxDecoration(color: c ?? rose, borderRadius: BorderRadius.circular(18)), child: Text(t, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16, color: Colors.white))));
  Widget stepper(String l, int v, int lo, int hi, void Function(int) f) => Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(children: [
        Expanded(child: Text(l)),
        IconButton(onPressed: v > lo ? () => f(v - 1) : null, icon: const Icon(Icons.remove_circle_outline)),
        SizedBox(width: 36, child: Center(child: bold('$v'))),
        IconButton(onPressed: v < hi ? () => f(v + 1) : null, icon: const Icon(Icons.add_circle_outline)),
      ]));

  Widget ring(double v, Color c, double size, Widget child) => TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: v.clamp(0.0, 1.0).toDouble()),
      duration: const Duration(milliseconds: 1100),
      curve: Curves.easeOutCubic,
      builder: (_, x, __) => SizedBox(width: size, height: size, child: CustomPaint(painter: Ring(x, c, 14), child: Center(child: child))));

  void celebrate(String e) {
    showDialog(
        context: context,
        builder: (d) => Center(child: TweenAnimationBuilder<double>(tween: Tween(begin: 0, end: 1), duration: const Duration(milliseconds: 800), curve: Curves.elasticOut, builder: (_, v, __) => Transform.scale(scale: v, child: Text(e, style: const TextStyle(fontSize: 90, decoration: TextDecoration.none))))));
    Future.delayed(const Duration(milliseconds: 1300), () {
      if (mounted) Navigator.of(context).pop();
    });
  }

  void startToday() {
    final k = key(today);
    if (!starts.contains(k)) {
      starts.add(k);
      starts.sort();
    }
    HapticFeedback.mediumImpact();
    save();
    resched();
    celebrate('🩷');
  }

  void setMood(String m) {
    final k = key(today);
    final e = dayLog(k);
    e['m'] = m;
    logs[k] = e;
    HapticFeedback.selectionClick();
    save();
  }

  // ---------- onboarding ----------
  void finishOb() {
    prof['name'] = nameC.text.trim();
    cl = obCl;
    pl = obPl;
    if (obDate != null) starts = [key(obDate!)];
    done = true;
    save();
    resched();
  }

  Widget onboard() {
    final s0 = Column(key: const ValueKey(0), mainAxisAlignment: MainAxisAlignment.center, children: [
      const Logo(90),
      const SizedBox(height: 24),
      bold('Welcome to Luna', s: 28),
      const SizedBox(height: 8),
      sm('Your private cycle companion. What should we call you?'),
      const SizedBox(height: 24),
      TextField(controller: nameC, textCapitalization: TextCapitalization.words, decoration: InputDecoration(labelText: 'Your name', border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)))),
      const SizedBox(height: 20),
      primary('Continue', () => setState(() => obStep = 1)),
    ]);
    final s1 = Column(key: const ValueKey(1), mainAxisAlignment: MainAxisAlignment.center, children: [
      bold('Your cycle', s: 28),
      const SizedBox(height: 8),
      sm('When did your last period start?'),
      const SizedBox(height: 16),
      OutlinedButton.icon(
          icon: const Icon(Icons.event_rounded),
          label: Text(obDate == null ? 'Pick date' : '${obDate!.day} ${mon[obDate!.month - 1]} ${obDate!.year}'),
          onPressed: () async {
            final d = await showDatePicker(context: context, initialDate: today, firstDate: add(today, -120), lastDate: today);
            if (d != null) setState(() => obDate = d);
          }),
      const SizedBox(height: 16),
      stepper('Cycle length (days)', obCl, 20, 45, (v) => setState(() => obCl = v)),
      stepper('Period length (days)', obPl, 2, 10, (v) => setState(() => obPl = v)),
      const SizedBox(height: 20),
      primary('Finish', finishOb),
      TextButton(
          onPressed: () {
            obDate = null;
            finishOb();
          },
          child: const Text("I don't remember")),
    ]);
    return Scaffold(body: SafeArea(child: Padding(padding: const EdgeInsets.all(28), child: AnimatedSwitcher(duration: const Duration(milliseconds: 400), child: obStep == 0 ? s0 : s1))));
  }

  // ---------- Today ----------
  Widget weekStrip() {
    final t = today, s = add(t, -(t.weekday % 7));
    return box(Row(children: List.generate(7, (i) {
      final x = add(s, i), per = isPeriod(x), pred = !per && isPred(x), f = fert(x), isT = dd(x, t) == 0;
      Color? fill = per ? rose : f == 2 ? teal : f == 1 ? teal.withOpacity(.2) : null;
      return Expanded(
          child: GestureDetector(
              onTap: () => logSheet(x),
              child: Column(children: [
                sm(wd[i].substring(0, 1), s: 12),
                const SizedBox(height: 6),
                Container(width: 38, height: 38, alignment: Alignment.center, decoration: BoxDecoration(shape: BoxShape.circle, color: fill, border: Border.all(color: isT ? rose : pred ? rose.withOpacity(.6) : Colors.transparent, width: isT ? 2.5 : 1.5)), child: Text('${x.day}', style: TextStyle(fontWeight: FontWeight.w700, color: per || f == 2 ? Colors.white : null))),
              ])));
    })));
  }

  Widget home() {
    final l = lastStart, n = today, k = key(n);
    final curMood = ((logs[k] ?? {})['m'] ?? '') as String;
    final hdr = Row(children: [
      const Logo(44),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [bold('Hi, ${name.isEmpty ? 'there' : name} 👋', s: 22), sm('${wd[n.weekday % 7]}, ${n.day} ${mon[n.month - 1]}')])),
    ]);
    if (l == null) {
      return ListView(physics: bounce, padding: pad, children: [
        hdr,
        const SizedBox(height: 30),
        anim(0, box(Column(children: [
          const Text('🌸', style: TextStyle(fontSize: 64)),
          const SizedBox(height: 12),
          bold('Log your last period', s: 22),
          const SizedBox(height: 8),
          sm('Luna will then predict your next period, fertile window and ovulation.'),
          const SizedBox(height: 20),
          primary('Log period date', () => logSheet(n)),
        ]))),
      ]);
    }
    final cd = dd(n, l) + 1, ph = phase(n), col = phCol[ph]!;
    final nx = add(l, clen), dn = dd(nx, n);
    var o = add(l, clen - 14);
    while (dd(o, n) < -1) {
      o = add(o, clen);
    }
    final fs = add(o, -5), fe = add(o, 1);
    final dn0 = starts.contains(k), ch = chance(n), w = warn();
    final ml = (wlog[k] ?? 0) as int;
    return ListView(physics: bounce, padding: pad, children: [
      hdr,
      const SizedBox(height: 16),
      anim(0, weekStrip()),
      anim(1, box(col: col.withOpacity(darkN.value ? .12 : .09), Column(children: [
        AnimatedBuilder(animation: pc, builder: (_, c) => Transform.scale(scale: 1 + pc.value * .03, child: c), child: ring(cd / clen, col, 230, Column(mainAxisSize: MainAxisSize.min, children: [
          sm('Cycle day'),
          Text('$cd', style: const TextStyle(fontSize: 60, fontWeight: FontWeight.w800)),
          Text(ph, style: TextStyle(color: col, fontWeight: FontWeight.w700, fontSize: 16)),
        ]))),
        const SizedBox(height: 18),
        Text(dn < 0 ? 'Period late by ${-dn} day${-dn == 1 ? '' : 's'}' : dn == 0 ? 'Period expected today' : 'Next period in $dn day${dn == 1 ? '' : 's'}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
        sm('${wd[nx.weekday % 7]}, ${nx.day} ${mon[nx.month - 1]}'),
        const SizedBox(height: 10),
        Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6), decoration: BoxDecoration(color: (ch == 'High' ? rose : ch == 'Medium' ? amb : teal).withOpacity(.15), borderRadius: BorderRadius.circular(20)), child: Text('Pregnancy chance today: $ch', style: TextStyle(fontWeight: FontWeight.w700, color: ch == 'High' ? rose : ch == 'Medium' ? amb : teal))),
      ]))),
      if (w != null) anim(2, box(col: amb.withOpacity(.15), Row(children: [const Icon(Icons.info_outline_rounded, color: amb), const SizedBox(width: 12), Expanded(child: Text(w))]))),
      anim(2, Row(children: [
        Expanded(child: box(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [sm('Fertile window'), const SizedBox(height: 4), Text('${fs.day} ${mon[fs.month - 1]} – ${fe.day} ${mon[fe.month - 1]}', style: const TextStyle(fontWeight: FontWeight.w700, color: teal))]))),
        const SizedBox(width: 12),
        Expanded(child: box(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [sm('Ovulation'), const SizedBox(height: 4), Text('${o.day} ${mon[o.month - 1]}', style: const TextStyle(fontWeight: FontWeight.w700, color: teal))]))),
      ])),
      anim(3, primary(dn0 ? 'Period logged today ✓' : 'Period started today', dn0 ? () {} : startToday, c: dn0 ? Colors.grey : rose)),
      anim(3, Bounce(onTap: () => setState(() => tab = 2), child: box(Row(children: [
        const Icon(Icons.water_drop_rounded, color: teal),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Water  $ml / $wg ml', style: const TextStyle(fontWeight: FontWeight.w700)), const SizedBox(height: 6), LinearProgressIndicator(value: (ml / wg).clamp(0.0, 1.0).toDouble(), minHeight: 8, color: teal, backgroundColor: line, borderRadius: BorderRadius.circular(8))])),
      ])))),
      anim(4, box(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        bold('How do you feel?'),
        const SizedBox(height: 12),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: moods.map((m) => GestureDetector(
            onTap: () => setMood(m),
            child: AnimatedScale(scale: curMood == m ? 1.25 : 1, duration: const Duration(milliseconds: 250), curve: Curves.easeOutBack, child: Container(padding: const EdgeInsets.all(8), decoration: BoxDecoration(shape: BoxShape.circle, color: curMood == m ? rose.withOpacity(.18) : Colors.transparent), child: Text(m.split(' ')[0], style: const TextStyle(fontSize: 30)))))).toList()),
      ]))),
      anim(5, box(col: col.withOpacity(darkN.value ? .12 : .09), Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('$ph phase · today for you', style: TextStyle(color: col, fontWeight: FontWeight.w700)),
        const SizedBox(height: 6),
        Text(tips[ph]!),
      ]))),
    ]);
  }

  // ---------- log sheet ----------
  void logSheet(DateTime day) {
    final k = key(day);
    final ex = dayLog(k);
    int flow = (ex['f'] ?? 0) as int, pain = (ex['p'] ?? 0) as int;
    String mood = (ex['m'] ?? '') as String;
    final sy = List<String>.from(ex['y'] ?? []);
    final note = TextEditingController(text: (ex['n'] ?? '') as String);
    bool start = starts.contains(k);
    showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        backgroundColor: cardC,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
        builder: (c) => StatefulBuilder(
            builder: (c, ss) => Padding(
                padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(c).viewInsets.bottom + 20),
                child: SingleChildScrollView(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                  bold('${wd[day.weekday % 7]}, ${day.day} ${mon[day.month - 1]}', s: 22),
                  SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('Period started this day'), value: start, onChanged: (v) => ss(() => start = v)),
                  label('Flow'),
                  Wrap(spacing: 8, children: List.generate(4, (i) => ChoiceChip(label: Text(flows[i]), selected: flow == i, onSelected: (_) => ss(() => flow = i)))),
                  label('Pain level: $pain / 10'),
                  Slider(value: pain.toDouble(), min: 0, max: 10, divisions: 10, activeColor: rose, onChanged: (v) => ss(() => pain = v.round())),
                  label('Mood'),
                  Wrap(spacing: 8, children: moods.map((m) => ChoiceChip(label: Text(m), selected: mood == m, onSelected: (_) => ss(() => mood = mood == m ? '' : m))).toList()),
                  label('Symptoms'),
                  Wrap(spacing: 8, children: syms.map((x) => FilterChip(label: Text(x), selected: sy.contains(x), onSelected: (v) => ss(() => v ? sy.add(x) : sy.remove(x)))).toList()),
                  const SizedBox(height: 10),
                  TextField(controller: note, decoration: const InputDecoration(labelText: 'Note (optional)')),
                  const SizedBox(height: 16),
                  primary('Save', () {
                    final e = Map.from(ex);
                    e['f'] = flow;
                    e['p'] = pain;
                    e['m'] = mood;
                    e['y'] = sy;
                    e['n'] = note.text;
                    if (flow == 0 && pain == 0 && mood.isEmpty && sy.isEmpty && note.text.isEmpty && e['t'] == null && e['w'] == null) {
                      logs.remove(k);
                    } else {
                      logs[k] = e;
                    }
                    if (start && !starts.contains(k)) {
                      starts.add(k);
                      starts.sort();
                    }
                    if (!start) starts.remove(k);
                    Navigator.pop(c);
                    HapticFeedback.mediumImpact();
                    save();
                    resched();
                  }),
                ])))));
  }

  // ---------- calendar ----------
  Widget cell(DateTime x) {
    final per = isPeriod(x), pred = !per && isPred(x), f = fert(x), isT = dd(x, today) == 0, has = logs.containsKey(key(x));
    Color? fill = per ? rose : f == 2 ? teal : f == 1 ? teal.withOpacity(.2) : null;
    return GestureDetector(
        onTap: () => logSheet(x),
        child: Container(
            margin: const EdgeInsets.all(3),
            decoration: BoxDecoration(shape: BoxShape.circle, color: fill, border: Border.all(color: isT ? lav : pred ? rose : Colors.transparent, width: isT ? 2.5 : 1.5)),
            child: Stack(alignment: Alignment.center, children: [
              Text('${x.day}', style: TextStyle(fontWeight: per || f == 2 ? FontWeight.w800 : FontWeight.w500, color: per || f == 2 ? Colors.white : null)),
              if (has) Positioned(bottom: 4, child: Container(width: 4, height: 4, decoration: BoxDecoration(shape: BoxShape.circle, color: per || f == 2 ? Colors.white : amb))),
            ])));
  }

  Widget cal() {
    final first = DateTime(month.year, month.month, 1);
    final lead = first.weekday % 7;
    final days = DateTime(month.year, month.month + 1, 0).day;
    final cells = <Widget>[for (var i = 0; i < lead; i++) const SizedBox(), for (var d = 1; d <= days; d++) cell(DateTime(month.year, month.month, d))];
    Widget dot(Color c, String t, {bool ring = false}) => Row(mainAxisSize: MainAxisSize.min, children: [Container(width: 12, height: 12, decoration: BoxDecoration(shape: BoxShape.circle, color: ring ? null : c, border: ring ? Border.all(color: c, width: 1.5) : null)), const SizedBox(width: 6), sm(t, s: 12)]);
    return ListView(physics: bounce, padding: pad, children: [
      title('Calendar'),
      box(Column(children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          IconButton(onPressed: () => setState(() => month = DateTime(month.year, month.month - 1)), icon: const Icon(Icons.chevron_left_rounded)),
          bold('${mon[month.month - 1]} ${month.year}', s: 18),
          IconButton(onPressed: () => setState(() => month = DateTime(month.year, month.month + 1)), icon: const Icon(Icons.chevron_right_rounded)),
        ]),
        Row(children: wd.map((w) => Expanded(child: Center(child: sm(w.substring(0, 1), s: 13)))).toList()),
        const SizedBox(height: 6),
        AnimatedSwitcher(duration: const Duration(milliseconds: 300), child: GridView.count(key: ValueKey(month), crossAxisCount: 7, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), children: cells)),
      ])),
      Wrap(spacing: 14, runSpacing: 8, children: [dot(rose, 'Period'), dot(rose, 'Predicted', ring: true), dot(teal, 'Fertile'), dot(teal, 'Ovulation'), dot(amb, 'Logged')]),
      const SizedBox(height: 10),
      sm('Tap any day to log flow, pain, mood and symptoms.', s: 13),
    ]);
  }

  // ---------- Track ----------
  List<MapEntry<String, double>> series(String f) {
    final ks = logs.keys.where((k) => logs[k][f] != null).map((k) => k.toString()).toList()..sort();
    return ks.map((k) => MapEntry<String, double>(k, (logs[k][f] as num).toDouble())).toList();
  }

  Future logVal(String f, String t) async {
    final v = double.tryParse((await ask(t) ?? '').replaceAll(',', '.'));
    if (v == null) return;
    final k = key(today);
    final e = dayLog(k);
    e[f] = v;
    logs[k] = e;
    save();
  }

  void addWater(int ml) {
    final k = key(today);
    final v = ((wlog[k] ?? 0) as int) + ml;
    wlog[k] = v < 0 ? 0 : v;
    HapticFeedback.lightImpact();
    save();
  }

  Widget waterCard() {
    final k = key(today), ml = (wlog[k] ?? 0) as int, r = (ml / wg).clamp(0.0, 1.0).toDouble();
    var streak = 0;
    for (var i = 0; i < 365; i++) {
      final v = (wlog[key(add(today, -i))] ?? 0) as int;
      if (v >= wg) {
        streak++;
      } else if (i > 0) {
        break;
      }
    }
    return box(Row(children: [
      Container(
          width: 76,
          height: 120,
          decoration: BoxDecoration(borderRadius: const BorderRadius.vertical(top: Radius.circular(10), bottom: Radius.circular(28)), border: Border.all(color: teal, width: 3)),
          child: ClipRRect(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(7), bottom: Radius.circular(25)),
              child: TweenAnimationBuilder<double>(tween: Tween(begin: 0, end: r), duration: const Duration(milliseconds: 900), curve: Curves.easeOutCubic, builder: (_, v, __) => Align(alignment: Alignment.bottomCenter, child: FractionallySizedBox(heightFactor: v, widthFactor: 1, child: Container(color: teal.withOpacity(.55))))))),
      const SizedBox(width: 18),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        bold('Water', s: 18),
        Text('$ml / $wg ml', style: const TextStyle(color: teal, fontWeight: FontWeight.w800, fontSize: 20)),
        sm(streak > 0 ? '🔥 $streak day streak' : 'Reach your goal to start a streak', s: 12),
        const SizedBox(height: 8),
        Wrap(spacing: 8, children: [150, 250, 500].map((m) => ActionChip(label: Text('+$m'), onPressed: () => addWater(m))).toList()),
        TextButton(onPressed: () => addWater(-250), child: const Text('Undo 250 ml')),
      ])),
    ]));
  }

  Widget valueCard(String t, String f, String unit, String hint) {
    final s = series(f), v = s.length > 14 ? s.sublist(s.length - 14) : s;
    return box(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [bold(t, s: 18), TextButton(onPressed: () => logVal(f, '$t ($unit)'), child: const Text('+ Log today'))]),
      if (v.isEmpty) sm(hint) else ...[
        SizedBox(height: 80, width: double.infinity, child: CustomPaint(painter: LineP(v.map((e) => e.value).toList(), f == 't' ? rose : lav))),
        const SizedBox(height: 6),
        sm('Latest: ${v.last.value} $unit${v.length > 1 ? '  ·  change ${(v.last.value - v.first.value).toStringAsFixed(1)}' : ''}'),
      ],
    ]));
  }

  Widget painCard() {
    final k = key(today);
    final p = ((logs[k] ?? {})['p'] ?? 0) as int;
    return box(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      bold('Pain today: $p / 10', s: 18),
      Slider(value: p.toDouble(), min: 0, max: 10, divisions: 10, activeColor: rose, onChanged: (v) {
        final e = dayLog(k);
        e['p'] = v.round();
        logs[k] = e;
        setState(() {});
      }, onChangeEnd: (_) => save()),
    ]));
  }

  Widget stockCard() {
    final need = pl * use, nx = lastStart == null ? null : add(lastStart!, clen);
    return box(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      bold('Pads / tampons stock', s: 18),
      Row(children: [
        IconButton(onPressed: stock > 0 ? () { stock--; save(); resched(); } : null, icon: const Icon(Icons.remove_circle_outline)),
        Text('$stock', style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
        IconButton(onPressed: () { stock++; save(); resched(); }, icon: const Icon(Icons.add_circle_outline)),
        const Spacer(),
        TextButton(onPressed: () { stock += 10; save(); resched(); }, child: const Text('+10')),
      ]),
      sm(stock >= need ? 'Enough for your next period ✓ (needs about $need)' : 'Buy about ${need - stock} more${nx == null ? '' : ' before ${nx.day} ${mon[nx.month - 1]}'} (needs about $need at $use/day).', s: 13),
    ]));
  }

  List<Widget> insTab() {
    final g = gaps, l6 = g.length > 6 ? g.sublist(g.length - 6) : g;
    final mx = l6.fold(1, (a, b) => b > a ? b : a);
    final reg = g.length < 2 ? '—' : ((g.reduce((a, b) => a > b ? a : b) - g.reduce((a, b) => a < b ? a : b)) <= 7 ? 'Regular' : 'Irregular');
    final sd = <String, List<int>>{};
    final mc = <String, int>{};
    final hm = <int, double>{};
    logs.forEach((k, v) {
      final d = DateTime.parse(k);
      DateTime? s;
      for (final x in st) {
        if (!x.isAfter(d)) s = x;
      }
      final ys = (v['y'] ?? []) as List;
      if (s != null) {
        final cd = dd(d, s) + 1;
        for (final y in ys) {
          (sd[y] ??= []).add(cd);
        }
        if (cd <= clen) hm[cd] = (hm[cd] ?? 0.0) + ys.length + ((v['p'] ?? 0) as num) / 3;
      }
      final m = (v['m'] ?? '') as String;
      if (m.isNotEmpty) mc[m] = (mc[m] ?? 0) + 1;
    });
    final top = sd.entries.toList()..sort((a, b) => b.value.length.compareTo(a.value.length));
    final mm = mc.values.fold(1, (a, b) => b > a ? b : a);
    final hmx = hm.values.fold(1.0, (a, b) => b > a ? b : a);
    final w = warn();
    return [
      if (w != null) box(col: amb.withOpacity(.15), Row(children: [const Icon(Icons.info_outline_rounded, color: amb), const SizedBox(width: 12), Expanded(child: Text(w))])),
      box(Column(children: [
        stat('Average cycle', '$clen days'),
        stat('Period length', '$pl days'),
        stat('Regularity', reg),
        stat('Cycles logged', '${g.length}'),
        stat('Last period', lastStart == null ? '—' : '${lastStart!.day} ${mon[lastStart!.month - 1]}'),
      ])),
      sec('Cycle length'),
      box(l6.isEmpty ? sm('Log two or more periods to see this chart.') : SizedBox(height: 150, child: Row(crossAxisAlignment: CrossAxisAlignment.end, mainAxisAlignment: MainAxisAlignment.spaceAround, children: l6.map((x) => Column(mainAxisAlignment: MainAxisAlignment.end, children: [
        Text('$x', style: const TextStyle(fontSize: 12)),
        const SizedBox(height: 4),
        TweenAnimationBuilder<double>(tween: Tween(begin: 0, end: 100 * x / mx), duration: const Duration(milliseconds: 900), curve: Curves.easeOutCubic, builder: (_, v, __) => Container(width: 26, height: v, decoration: BoxDecoration(color: rose, borderRadius: BorderRadius.circular(8)))),
      ])).toList()))),
      sec('Symptom & pain heatmap'),
      box(hm.isEmpty ? sm('Log symptoms and pain to see which cycle days feel worst.') : Wrap(spacing: 6, runSpacing: 6, children: List.generate(clen, (i) {
        final v = (hm[i + 1] ?? 0.0) / hmx;
        return Container(width: 34, height: 34, alignment: Alignment.center, decoration: BoxDecoration(color: rose.withOpacity(.07 + .85 * v), borderRadius: BorderRadius.circular(10)), child: Text('${i + 1}', style: TextStyle(fontSize: 11, color: v > .5 ? Colors.white : sub)));
      }))),
      sec('Symptom patterns'),
      box(Column(children: top.isEmpty ? [sm('Log symptoms to see patterns.')] : top.take(4).map((e) => stat(e.key, 'usually day ${(e.value.reduce((a, b) => a + b) / e.value.length).round()} · ${e.value.length}x')).toList())),
      sec('Moods'),
      box(Column(children: mc.isEmpty ? [sm('Log your mood to see this.')] : mc.entries.map((e) => Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('${e.key}  ·  ${e.value}'),
        const SizedBox(height: 6),
        TweenAnimationBuilder<double>(tween: Tween(begin: 0, end: e.value / mm), duration: const Duration(milliseconds: 900), curve: Curves.easeOutCubic, builder: (_, v, __) => LinearProgressIndicator(value: v, minHeight: 8, color: lav, backgroundColor: line, borderRadius: BorderRadius.circular(8))),
      ]))).toList())),
      primary('View doctor report', showReport),
    ];
  }

  Widget track() => ListView(physics: bounce, padding: pad, children: [
        title('Track'),
        SizedBox(width: double.infinity, child: SegmentedButton<int>(segments: const [ButtonSegment(value: 0, label: Text('Log')), ButtonSegment(value: 1, label: Text('Insights'))], selected: {seg}, onSelectionChanged: (v) => setState(() => seg = v.first))),
        const SizedBox(height: 16),
        if (seg == 0) ...[
          anim(0, waterCard()),
          anim(1, valueCard('Body temperature', 't', '°C', 'Log your morning temperature. A small rise after ovulation helps confirm it.')),
          anim(2, valueCard('Weight', 'w', 'kg', 'Log your weight to see trends across your cycle.')),
          anim(3, painCard()),
          anim(4, stockCard()),
        ] else
          ...insBody(),
      ]);

  List<Widget> insBody() => insTab();

  String report() {
    final b = StringBuffer();
    b.writeln('Cycle report${name.isEmpty ? '' : ' · $name'}');
    b.writeln('Generated: ${key(today)}');
    b.writeln('Average cycle: $clen days · Period length: $pl days');
    final s = st, last = s.length > 6 ? s.sublist(s.length - 6) : s;
    b.writeln('Recent period start dates: ${last.map(key).join(', ')}');
    b.writeln('Cycle lengths (days): ${gaps.isEmpty ? '—' : gaps.join(', ')}');
    final cnt = <String, int>{};
    logs.forEach((k, v) {
      for (final y in ((v['y'] ?? []) as List)) {
        cnt[y] = (cnt[y] ?? 0) + 1;
      }
    });
    final top = cnt.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    b.writeln('Most logged symptoms: ${top.isEmpty ? '—' : top.take(5).map((e) => '${e.key} (${e.value}x)').join(', ')}');
    if (pf('blood').isNotEmpty) b.writeln('Blood group: ${pf('blood')}');
    if (pf('allergy').isNotEmpty) b.writeln('Allergies / notes: ${pf('allergy')}');
    b.writeln('Note: dates are self-logged estimates, not a diagnosis.');
    return b.toString();
  }

  void showReport() {
    final r = report();
    showDialog(
        context: context,
        builder: (d) => AlertDialog(title: const Text('Doctor report'), content: SingleChildScrollView(child: SelectableText(r)), actions: [
              TextButton(onPressed: () => Navigator.pop(d), child: const Text('Close')),
              TextButton(
                  onPressed: () {
                    Clipboard.setData(ClipboardData(text: r));
                    Navigator.pop(d);
                    snack('Report copied. Paste it into a message to share.');
                  },
                  child: const Text('Copy')),
            ]));
  }

  // ---------- Alerts ----------
  Widget notifCard(String k) {
    final c = cfgOf(k), on = c['on'] == true;
    final tm = TimeOfDay(hour: c['h'] as int, minute: c['m'] as int);
    return box(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [bold(defs[k]![0], s: 17), Switch(value: on, activeColor: rose, onChanged: (v) => setCfg(k, 'on', v))]),
      if (on) ...[
        Wrap(crossAxisAlignment: WrapCrossAlignment.center, spacing: 6, children: [
          TextButton.icon(
              icon: const Icon(Icons.schedule_rounded, size: 18),
              label: Text(k == 'water' ? 'From ${tm.format(context)}' : tm.format(context)),
              onPressed: () async {
                final t = await showTimePicker(context: context, initialTime: tm);
                if (t != null) {
                  cfg[k] = {...cfgOf(k), 'h': t.hour, 'm': t.minute};
                  save();
                  resched();
                }
              }),
          if (k == 'period') ...[1, 2, 3].map((i) => ChoiceChip(label: Text('${i}d before'), selected: c['n'] == i, onSelected: (_) => setCfg(k, 'n', i))),
          if (k == 'water') ...[1, 2, 3, 4].map((i) => ChoiceChip(label: Text('every ${i}h'), selected: c['n'] == i, onSelected: (_) => setCfg(k, 'n', i))),
        ]),
        sm(c['msg'] as String),
        TextButton(
            onPressed: () async {
              final r = await ask('Custom message', number: false, init: c['msg'] as String);
              if (r != null && r.trim().isNotEmpty) setCfg(k, 'msg', r.trim());
            },
            child: const Text('Edit message')),
      ],
    ]));
  }

  void remSheet([int? idx]) {
    final Map ex = idx == null ? {} : Map.from(rems[idx]);
    final tc = TextEditingController(text: (ex['t'] ?? '') as String), bc = TextEditingController(text: (ex['b'] ?? '') as String);
    int h = (ex['h'] ?? 8) as int, m = (ex['m'] ?? 0) as int;
    final days = List<int>.from(ex['d'] ?? []);
    showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        backgroundColor: cardC,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
        builder: (c) => StatefulBuilder(
            builder: (c, ss) => Padding(
                padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(c).viewInsets.bottom + 20),
                child: SingleChildScrollView(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                  bold(idx == null ? 'New reminder' : 'Edit reminder', s: 22),
                  TextField(controller: tc, decoration: const InputDecoration(labelText: 'Title')),
                  TextField(controller: bc, decoration: const InputDecoration(labelText: 'Message (optional)')),
                  const SizedBox(height: 8),
                  TextButton.icon(
                      icon: const Icon(Icons.schedule_rounded),
                      label: Text(TimeOfDay(hour: h, minute: m).format(c)),
                      onPressed: () async {
                        final t = await showTimePicker(context: c, initialTime: TimeOfDay(hour: h, minute: m));
                        if (t != null) ss(() {
                          h = t.hour;
                          m = t.minute;
                        });
                      }),
                  label('Repeat on (none selected = every day)'),
                  Wrap(spacing: 6, children: List.generate(7, (i) => FilterChip(label: Text(['M','T','W','T','F','S','S'][i]), selected: days.contains(i + 1), onSelected: (v) => ss(() => v ? days.add(i + 1) : days.remove(i + 1))))),
                  const SizedBox(height: 16),
                  Row(children: [
                    if (idx != null) TextButton(onPressed: () { rems.removeAt(idx); Navigator.pop(c); save(); resched(); }, child: const Text('Delete', style: TextStyle(color: Colors.redAccent))),
                    const Spacer(),
                    FilledButton(
                        style: FilledButton.styleFrom(backgroundColor: rose, foregroundColor: Colors.white),
                        onPressed: () {
                          if (tc.text.trim().isEmpty) return;
                          final r = {'t': tc.text.trim(), 'b': bc.text.trim().isEmpty ? tc.text.trim() : bc.text.trim(), 'h': h, 'm': m, 'd': days, 'on': true};
                          if (idx == null) {
                            rems.add(r);
                          } else {
                            rems[idx] = r;
                          }
                          Navigator.pop(c);
                          save();
                          resched();
                        },
                        child: const Text('Save')),
                  ]),
                ])))));
  }

  Widget alerts() => ListView(physics: bounce, padding: pad, children: [
        title('Alerts'),
        ...defs.keys.toList().asMap().entries.map((e) => anim(e.key, notifCard(e.value))),
        Row(children: [Expanded(child: sec('My reminders')), IconButton(onPressed: () => remSheet(), icon: const Icon(Icons.add_circle_rounded, color: rose, size: 30))]),
        if (rems.isEmpty) sm('Add your own reminders: vitamins, doctor visits, exercise, anything.'),
        ...rems.asMap().entries.map((e) {
          final r = e.value;
          final days = List<int>.from(r['d'] ?? []);
          return box(Row(children: [
            Expanded(child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () => remSheet(e.key),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  bold('${r['t']}'),
                  sm('${TimeOfDay(hour: r['h'] as int, minute: r['m'] as int).format(context)} · ${days.isEmpty ? 'Every day' : days.map((d) => ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'][d - 1]).join(', ')}', s: 13),
                ]))),
            Switch(value: r['on'] == true, activeColor: rose, onChanged: (v) {
              r['on'] = v;
              save();
              resched();
            }),
          ]));
        }),
        sec('Check notifications'),
        primary('Fix notification permission', () async {
          final r = await perms();
          snack(r == 'ok' ? 'Permission OK' : r);
          resched();
        }),
        OutlinedButton.icon(
            icon: const Icon(Icons.notifications_active_rounded),
            label: const Text('Send test now'),
            onPressed: () async {
              try {
                await np.show(0, 'Luna', 'Notifications are working ✓', nd);
              } catch (e) {
                snack('Failed: $e');
              }
            }),
        OutlinedButton.icon(
            icon: const Icon(Icons.timer_rounded),
            label: const Text('Test in 1 minute (scheduled)'),
            onPressed: () async {
              try {
                await sched(9999, 'Luna', 'Scheduled reminder worked ✓', now.add(const Duration(minutes: 1)));
                snack('Scheduled. Lock your phone and wait 1 minute.');
              } catch (e) {
                snack('Failed: $e');
              }
            }),
        const SizedBox(height: 10),
        sm(schedInfo.isEmpty ? 'Checking…' : schedInfo, s: 13),
        const SizedBox(height: 6),
        sm('For on-time reminders: allow notifications and alarms for Luna and turn off battery optimisation (Settings → Apps → Luna → Battery → Unrestricted).', s: 12),
      ]);

  // ---------- Profile ----------
  Widget tile(IconData i, String t, String s, VoidCallback f) => ListTile(contentPadding: EdgeInsets.zero, leading: Icon(i, color: rose), title: Text(t), subtitle: s.isEmpty ? null : Text(s), trailing: const Icon(Icons.chevron_right), onTap: f);

  Widget profile() => ListView(physics: bounce, padding: pad, children: [
        title('Profile'),
        anim(0, box(Row(children: [
          CircleAvatar(radius: 34, backgroundColor: rose.withOpacity(.15), child: Text(name.isEmpty ? '🌸' : name.substring(0, 1).toUpperCase(), style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: rose))),
          const SizedBox(width: 16),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [bold(name.isEmpty ? 'Add your name' : name, s: 22), sm('${gaps.length} cycles logged · avg $clen days')])),
          IconButton(onPressed: () => editProf('name', 'Your name'), icon: const Icon(Icons.edit_rounded, color: rose)),
        ]))),
        sec('Cycle & goals'),
        box(Column(children: [
          tile(Icons.loop_rounded, 'Typical cycle length', '$cl days (used until 2 cycles are logged)', () async {
            final v = int.tryParse(await ask('Cycle length (20-45)') ?? '');
            if (v != null && v >= 20 && v <= 45) {
              cl = v;
              save();
              resched();
            }
          }),
          tile(Icons.opacity_rounded, 'Period length', '$pl days', () async {
            final v = int.tryParse(await ask('Period length (2-10)') ?? '');
            if (v != null && v >= 2 && v <= 10) {
              pl = v;
              save();
            }
          }),
          tile(Icons.water_drop_rounded, 'Daily water goal', '$wg ml', () async {
            final v = int.tryParse(await ask('Water goal in ml') ?? '');
            if (v != null && v >= 500 && v <= 6000) {
              wg = v;
              save();
            }
          }),
          tile(Icons.inventory_2_rounded, 'Pads / tampons per day', '$use', () async {
            final v = int.tryParse(await ask('Per day (1-15)') ?? '');
            if (v != null && v >= 1 && v <= 15) {
              use = v;
              save();
              resched();
            }
          }),
        ])),
        sec('Emergency info'),
        box(Column(children: [
          tile(Icons.bloodtype_rounded, 'Blood group', pf('blood').isEmpty ? 'Not set' : pf('blood'), () => editProf('blood', 'Blood group')),
          tile(Icons.medical_information_rounded, 'Allergies / notes', pf('allergy').isEmpty ? 'Not set' : pf('allergy'), () => editProf('allergy', 'Allergies or medical notes')),
          tile(Icons.contact_phone_rounded, 'Emergency contact', pf('contact').isEmpty ? 'Not set' : pf('contact'), () => editProf('contact', 'Name and phone number')),
        ])),
        sec('Privacy & look'),
        box(Column(children: [
          SwitchListTile(contentPadding: EdgeInsets.zero, secondary: const Icon(Icons.dark_mode_rounded, color: rose), title: const Text('Dark mode'), value: darkN.value, activeColor: rose, onChanged: (v) {
            darkN.value = v;
            save();
          }),
          SwitchListTile(contentPadding: EdgeInsets.zero, secondary: const Icon(Icons.visibility_off_rounded, color: rose), title: const Text('Hide notification text'), subtitle: const Text('Reminders only say "Luna"'), value: hide, activeColor: rose, onChanged: (v) {
            hide = v;
            save();
            resched();
          }),
          tile(pin.isEmpty ? Icons.lock_open_rounded : Icons.lock_rounded, pin.isEmpty ? 'Set app lock (PIN)' : 'Remove app lock', '', () async {
            if (pin.isNotEmpty) {
              pin = '';
              save();
              snack('App lock removed');
              return;
            }
            final v = await ask('Choose a 4-digit PIN');
            if (v != null && v.length == 4 && int.tryParse(v) != null) {
              pin = v;
              save();
              snack('App lock on');
            }
          }),
        ])),
        sec('Data'),
        box(Column(children: [
          tile(Icons.description_rounded, 'Doctor report', 'Summary of your cycles to share', showReport),
          tile(Icons.copy_rounded, 'Copy backup', 'Paste it somewhere safe (Notes, WhatsApp)', () {
            Clipboard.setData(ClipboardData(text: jsonEncode(toMap())));
            snack('Backup copied');
          }),
          tile(Icons.restore_rounded, 'Restore backup', '', () async {
            final r = await ask('Paste backup here', number: false);
            if (r == null || r.isEmpty) return;
            try {
              fromMap(jsonDecode(r));
              done = true;
              await save();
              resched();
              snack('Restored');
            } catch (_) {
              snack('Invalid backup');
            }
          }),
        ])),
        sm('Your data stays on this phone. Luna gives estimates only. It is not medical advice and not a method of birth control.', s: 12),
      ]);

  @override
  Widget build(BuildContext context) {
    if (!loaded) return const Scaffold();
    if (!done) return onboard();
    if (locked) return PinLock(pin, () => setState(() => locked = false));
    final pages = [home(), cal(), track(), alerts(), profile()];
    return Scaffold(
      body: SafeArea(child: AnimatedSwitcher(duration: const Duration(milliseconds: 300), child: KeyedSubtree(key: ValueKey(tab), child: pages[tab]))),
      bottomNavigationBar: NavigationBar(selectedIndex: tab, onDestinationSelected: (i) {
        HapticFeedback.selectionClick();
        setState(() => tab = i);
      }, destinations: const [
        NavigationDestination(icon: Icon(Icons.favorite_rounded), label: 'Today'),
        NavigationDestination(icon: Icon(Icons.calendar_month_rounded), label: 'Calendar'),
        NavigationDestination(icon: Icon(Icons.show_chart_rounded), label: 'Track'),
        NavigationDestination(icon: Icon(Icons.notifications_rounded), label: 'Alerts'),
        NavigationDestination(icon: Icon(Icons.person_rounded), label: 'Profile'),
      ]),
    );
  }
}
