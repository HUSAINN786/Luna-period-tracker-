import re, sys, os
a = sys.argv[1]
mp = a + '/android/app/src/main/AndroidManifest.xml'
s = open(mp).read()
perms = '''<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED"/>
    <uses-permission android:name="android.permission.VIBRATE"/>
    <uses-permission android:name="android.permission.USE_EXACT_ALARM"/>
    <uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" android:maxSdkVersion="32"/>
    '''
rec = '''<receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver"/>
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED"/>
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED"/>
                <action android:name="android.intent.action.QUICKBOOT_POWERON"/>
                <action android:name="com.htc.intent.action.QUICKBOOT_POWERON"/>
            </intent-filter>
        </receiver>
    '''
s = s.replace('<application', perms + '<application', 1)
s = s.replace('</application>', rec + '</application>', 1)
s = re.sub(r'android:label="[^"]*"', 'android:label="Luna"', s, 1)
open(mp, 'w').write(s)
for f in (a + '/android/app/build.gradle.kts', a + '/android/app/build.gradle'):
    if not os.path.exists(f):
        continue
    g = open(f).read()
    if f.endswith('.kts'):
        g = g.replace('compileOptions {', 'compileOptions {\n        isCoreLibraryDesugaringEnabled = true', 1)
        g = g.replace('release {', 'release {\n            isMinifyEnabled = false\n            isShrinkResources = false', 1)
        g += '\ndependencies {\n    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")\n}\n'
    else:
        g = g.replace('compileOptions {', 'compileOptions {\n        coreLibraryDesugaringEnabled true', 1)
        g = g.replace('release {', 'release {\n            minifyEnabled false\n            shrinkResources false', 1)
        g += "\ndependencies {\n    coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.1.4'\n}\n"
    open(f, 'w').write(g)
print('patched')
